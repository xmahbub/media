from flask import Flask,jsonify,Blueprint,render_template,url_for,request
import json
import os
import subprocess
from flask import jsonify
app = Flask(__name__)


@app.route('/Execute/<string:value>/<string:value2>',methods=["GET"])
def Execute(value,value2):
    
    returned_output = subprocess.check_output([value,value2])

    return returned_output.decode("utf-8").replace("\n","<br>")


@app.route('/WPScan/<string:domain>/<string:vt>/<string:key>',methods=["GET"])
def WPScan(domain,vt,key):
    def work():
      process = subprocess.Popen(["wpscan","--url",domain,"-e",vt,"--api-token",key],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
      returncode = process.wait()
      #print('ping returned {0}'.format(returncode))
      return process.stdout.read().decode("utf-8").replace("\n","<br>").replace("[32m[+][0m",'<b><font color="green">[+]</font></b>').replace("[33m[!][0m",'<b><font color="red">[!]</font></b>').replace("[34m[i][0m",'<b><font color="blue">[i]</font></b>').replace("https://automattic.com/","https://itcandle.tech").replace("[31m[!][0m",'<b><font color="red">[ ! ]</font></b>').replace("WPScan Team","ITCandle").replace("Automattic","ITCandle").replace("@_WPScan_, @ethicalhack3r, @erwan_lr, @firefart","@Mahbub_Hasan, @Abid_Ahmed")
    return work()

@app.route('/',methods=["GET","POST"])
def index():
    if request.method == "POST":
        #return request.form["domain"]+request.form["vt"]
        def work():
           process = subprocess.Popen(["wpscan","--url",request.form["domain"],"-e",request.form["vt"],"--api-token",request.form["keyy"]],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
           returncode = process.wait()
           #print('ping returned {0}'.format(returncode))
           return process.stdout.read().decode("utf-8").replace("\n","<br>").replace("[32m[+][0m",'<b><font color="green">[+]</font></b>').replace("[33m[!][0m",'<b><font color="red">[!]</font></b>').replace("[34m[i][0m",'<b><font color="blue">[i]</font></b>').replace("https://automattic.com/","https://itcandle.tech").replace("[31m[!][0m",'<b><font color="red">[ ! ]</font></b>').replace("WPScan Team","ITCandle").replace("Automattic","ITCandle").replace("@_WPScan_, @ethicalhack3r, @erwan_lr, @firefart","@Mahbub_Hasan, @Abid_Ahmed")
        return work()
    else:
       return render_template("index.html")

@app.route('/Sublister/<string:value>',methods=["GET"])
def Sublister(value):
    
    returned_output = subprocess.check_output(["sublist3r","-d",value])

    return returned_output.decode("utf-8").replace("\n","<br>").replace("[92m","").replace("[0m","").replace("[91m[!]","").replace("[91m[~]","").replace("[93m[-]","").replace("m[-]","").replace("[94m[-]","").replace("[94","")

@app.errorhandler(404)
def page_not_found(e):
    # note that we set the 404 status explicitly
    return "404 Not Found"


if __name__ == "__main__":
    app.debug = True
    app.run(host='0.0.0.0')